const KEY="tiigsi_registrations";
const form=document.getElementById("registrationForm");
const message=document.getElementById("message");
form.addEventListener("submit",e=>{
  e.preventDefault();
  if(!form.checkValidity()){form.reportValidity();return;}
  const fd=new FormData(form);
  const item={
    id:crypto.randomUUID?crypto.randomUUID():Date.now().toString(),
    name:fd.get("name").trim(),number:fd.get("number").trim(),school:fd.get("school").trim(),
    course:fd.get("course"),grade:fd.get("grade").trim(),gender:fd.get("gender"),
    date:new Date().toLocaleDateString("en-CA")
  };
  const data=JSON.parse(localStorage.getItem(KEY)||"[]");
  data.unshift(item);localStorage.setItem(KEY,JSON.stringify(data));
  form.reset();
  message.textContent="✓ Waad ku guulaysatay isdiiwaangelinta. Mahadsanid!";
  setTimeout(()=>message.textContent="",5000);
});